// ignore_for_file: prefer_const_constructors

import 'package:flutter/material.dart';

class E1aPage extends StatefulWidget {
  const E1aPage({super.key});

  @override
  State<E1aPage> createState() => _E1aPageState();
}

class _E1aPageState extends State<E1aPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Placeholder(),
    );
  }
}
