enum Combustible {
    diesel,
    gasolina
}