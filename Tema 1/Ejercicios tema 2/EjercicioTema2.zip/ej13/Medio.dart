enum Medio {
    terrestre,
    aereo,
    acuatico,
    subacuatico
}