enum Traccion {
    pedales,
    remo,
    animal
}