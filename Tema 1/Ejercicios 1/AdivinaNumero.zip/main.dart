import 'package:ejercicio1/funciones.dart' as funciones;

void main(List<String> arguments) {
  funciones.adivinaElNumero(max: 1000);
}
